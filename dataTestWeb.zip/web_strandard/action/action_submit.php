<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Action</title>
</head>
<body>
    <p>First name : <?php echo $_GET["fistname"]; ?></p>
    <p>Last name : <?php echo $_GET["lastname"]; ?></p>
    <p>E-mail : <?php echo $_GET["e-mail"]; ?></p>
</body>
</html>